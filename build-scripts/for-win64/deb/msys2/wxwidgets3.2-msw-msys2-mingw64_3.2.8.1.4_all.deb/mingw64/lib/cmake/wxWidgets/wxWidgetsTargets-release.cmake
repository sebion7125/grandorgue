#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "wx::wxbase" for configuration "Release"
set_property(TARGET wx::wxbase APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxbase PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_baseu-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxbase32u_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxbase )
list(APPEND _cmake_import_check_files_for_wx::wxbase "${_IMPORT_PREFIX}/lib/libwx_baseu-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxbase32u_gcc_custom.dll" )

# Import target "wx::wxnet" for configuration "Release"
set_property(TARGET wx::wxnet APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxnet PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_baseu_net-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxbase32u_net_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxnet )
list(APPEND _cmake_import_check_files_for_wx::wxnet "${_IMPORT_PREFIX}/lib/libwx_baseu_net-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxbase32u_net_gcc_custom.dll" )

# Import target "wx::wxcore" for configuration "Release"
set_property(TARGET wx::wxcore APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxcore PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_core-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_core_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxcore )
list(APPEND _cmake_import_check_files_for_wx::wxcore "${_IMPORT_PREFIX}/lib/libwx_mswu_core-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_core_gcc_custom.dll" )

# Import target "wx::wxadv" for configuration "Release"
set_property(TARGET wx::wxadv APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxadv PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_adv-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_adv_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxadv )
list(APPEND _cmake_import_check_files_for_wx::wxadv "${_IMPORT_PREFIX}/lib/libwx_mswu_adv-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_adv_gcc_custom.dll" )

# Import target "wx::wxaui" for configuration "Release"
set_property(TARGET wx::wxaui APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxaui PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_aui-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_aui_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxaui )
list(APPEND _cmake_import_check_files_for_wx::wxaui "${_IMPORT_PREFIX}/lib/libwx_mswu_aui-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_aui_gcc_custom.dll" )

# Import target "wx::wxhtml" for configuration "Release"
set_property(TARGET wx::wxhtml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxhtml PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_html-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_html_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxhtml )
list(APPEND _cmake_import_check_files_for_wx::wxhtml "${_IMPORT_PREFIX}/lib/libwx_mswu_html-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_html_gcc_custom.dll" )

# Import target "wx::wxpropgrid" for configuration "Release"
set_property(TARGET wx::wxpropgrid APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxpropgrid PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_propgrid-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_propgrid_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxpropgrid )
list(APPEND _cmake_import_check_files_for_wx::wxpropgrid "${_IMPORT_PREFIX}/lib/libwx_mswu_propgrid-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_propgrid_gcc_custom.dll" )

# Import target "wx::wxribbon" for configuration "Release"
set_property(TARGET wx::wxribbon APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxribbon PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_ribbon-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_ribbon_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxribbon )
list(APPEND _cmake_import_check_files_for_wx::wxribbon "${_IMPORT_PREFIX}/lib/libwx_mswu_ribbon-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_ribbon_gcc_custom.dll" )

# Import target "wx::wxrichtext" for configuration "Release"
set_property(TARGET wx::wxrichtext APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxrichtext PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_richtext-3.2.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "wx::wxhtml;wx::wxxml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_richtext_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxrichtext )
list(APPEND _cmake_import_check_files_for_wx::wxrichtext "${_IMPORT_PREFIX}/lib/libwx_mswu_richtext-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_richtext_gcc_custom.dll" )

# Import target "wx::wxwebview" for configuration "Release"
set_property(TARGET wx::wxwebview APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxwebview PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_webview-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_webview_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxwebview )
list(APPEND _cmake_import_check_files_for_wx::wxwebview "${_IMPORT_PREFIX}/lib/libwx_mswu_webview-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_webview_gcc_custom.dll" )

# Import target "wx::wxstc" for configuration "Release"
set_property(TARGET wx::wxstc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxstc PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_stc-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_stc_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxstc )
list(APPEND _cmake_import_check_files_for_wx::wxstc "${_IMPORT_PREFIX}/lib/libwx_mswu_stc-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_stc_gcc_custom.dll" )

# Import target "wx::wxxrc" for configuration "Release"
set_property(TARGET wx::wxxrc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxxrc PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_xrc-3.2.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "wx::wxhtml;wx::wxxml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_xrc_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxxrc )
list(APPEND _cmake_import_check_files_for_wx::wxxrc "${_IMPORT_PREFIX}/lib/libwx_mswu_xrc-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_xrc_gcc_custom.dll" )

# Import target "wx::wxmedia" for configuration "Release"
set_property(TARGET wx::wxmedia APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxmedia PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_media-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_media_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxmedia )
list(APPEND _cmake_import_check_files_for_wx::wxmedia "${_IMPORT_PREFIX}/lib/libwx_mswu_media-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_media_gcc_custom.dll" )

# Import target "wx::wxgl" for configuration "Release"
set_property(TARGET wx::wxgl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxgl PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_gl-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_gl_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxgl )
list(APPEND _cmake_import_check_files_for_wx::wxgl "${_IMPORT_PREFIX}/lib/libwx_mswu_gl-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_gl_gcc_custom.dll" )

# Import target "wx::wxqa" for configuration "Release"
set_property(TARGET wx::wxqa APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxqa PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_mswu_qa-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxmsw32u_qa_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxqa )
list(APPEND _cmake_import_check_files_for_wx::wxqa "${_IMPORT_PREFIX}/lib/libwx_mswu_qa-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxmsw32u_qa_gcc_custom.dll" )

# Import target "wx::wxxml" for configuration "Release"
set_property(TARGET wx::wxxml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wx::wxxml PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libwx_baseu_xml-3.2.dll.a"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/wxbase32u_xml_gcc_custom.dll"
  )

list(APPEND _cmake_import_check_targets wx::wxxml )
list(APPEND _cmake_import_check_files_for_wx::wxxml "${_IMPORT_PREFIX}/lib/libwx_baseu_xml-3.2.dll.a" "${_IMPORT_PREFIX}/bin/wxbase32u_xml_gcc_custom.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
